print("Hello, my name is Rahul Tripathi!")
print("Welcome to Python programming.")
