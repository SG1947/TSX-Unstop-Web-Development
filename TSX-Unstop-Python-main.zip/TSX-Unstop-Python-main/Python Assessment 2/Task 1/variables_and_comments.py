# This script prints a greeting with your name
name = "Anupam"  # Storing your name in a variable
print("Hello, " + name + "!")  # Greeting message
