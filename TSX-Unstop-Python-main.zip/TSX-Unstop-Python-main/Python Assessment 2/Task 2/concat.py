# Concatenate two strings
first_name = "Alice"
last_name = "Smith"

full_name = first_name + " " + last_name
print("Full Name:", full_name)
