# Compare two numbers from user input
a = int(input("Enter first number: "))
b = int(input("Enter second number: "))

if a > b:
    print("First number is greater.")
elif a < b:
    print("First number is less.")
else:
    print("Both numbers are equal.")
