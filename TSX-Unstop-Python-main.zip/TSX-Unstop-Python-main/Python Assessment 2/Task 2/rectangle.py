# Calculate area and perimeter of a rectangle
length = 5
width = 3

area = length * width
perimeter = 2 * (length + width)

print("Area:", area)
print("Perimeter:", perimeter)

