# Arithmetic and logical operator examples
print("Addition:", 5 + 3)
print("Division:", 10 / 2)
print("Modulus:", 7 % 2)
print("Logical AND:", 3 > 1 and 4 < 6)
